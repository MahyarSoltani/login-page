let eyeIcon = document.querySelector('#icon');
let inpPass = document.querySelector('#userPass');

inpPass.addEventListener('keyup', function(){
    let inpPassLength = inpPass.value.length;

    if(inpPassLength == 0){
        eyeIcon.style.display = 'none';
    } else{
        eyeIcon.style.display = 'inline-block';
    }
});

eyeIcon.addEventListener('click', function(){
    let passInpType = inpPass.getAttribute('type');

    if(passInpType == 'password'){
        inpPass.setAttribute('type', 'text');
        eyeIcon.setAttribute('src', 'images/0.png');
    } else{
        inpPass.setAttribute('type', 'password');
        eyeIcon.setAttribute('src', 'images/1.png');
    }
    
});